# 실습용 데이터 파일
실습용 데이터 파일입니다. 다운로드해서 프로젝트 폴더에 삽입한 후 실습을 진행하세요.

## 다운로드 방법
- ① 다운로드할 파일 클릭
- ② `Raw` 버튼 또는 `Download` 버튼 마우스 오른쪽 클릭
- ③ [다른 이름으로 링크 저장] 클릭

## 주요 파일
파일           | 내용
:------------- |:-------------
[excel_exam.xlsx](https://github.com/youngwoos/Doit_R/blob/master/Data/excel_exam.xlsx) | 04-3절. 엑셀 파일
[csv_exam.csv](https://github.com/youngwoos/Doit_R/blob/master/Data/csv_exam.csv) | 04-3절. CSV 파일
[Koweps_hpc10_2015_beta1.sav](http://bit.ly/Koweps_hpc10_2015_v2) | 09-1절. 한국복지패널데이터
[Koweps_Codebook.xlsx](https://github.com/youngwoos/Doit_R/blob/master/Data/Koweps_Codebook.xlsx) | 09-1절. 복지패널데이터 실습용 변수, 09-6절. 직업 분류 코드
[hiphop.txt](https://github.com/youngwoos/Doit_R/blob/master/Data/hiphop.txt) | 10-1절. 힙합 가사
[twitter.csv](https://github.com/youngwoos/Doit_R/blob/master/Data/twitter.csv) | 10-2절. 국정원 트윗
